
<!DOCTYPE html>
<html>
<head>
    <title>Inscription Réussie</title>
</head>
<body>
    <h1>Inscription Réussie!</h1>
    <p>Votre inscription a été effectuée avec succès.</p>
    <a href="login.php">Cliquez ici pour vous connecter</a>
</body>
</html>
