<footer>
        <!-- Contenu du pied de page -->
    </footer>
</body>
</html>